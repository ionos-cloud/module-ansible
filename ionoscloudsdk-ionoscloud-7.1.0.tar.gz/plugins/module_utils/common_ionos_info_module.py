class CommonIonosModule():


    def get_objects(module, client):
        pass
